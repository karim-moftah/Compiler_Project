class Main {  // block number0
    public static void main(String[] args) {  // block number1
        int x = 0;
        int expression = 9;
        if( x == true ) {  // block number2

            if ( x == true)
                System.out.println("this is not a block");

            if (z  == false){  // block number3
                System.out.println("this is a block");
            }
        }
    }
}