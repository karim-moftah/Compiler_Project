class Main {
    public static void main(String[] args) {
        int x = 0;
        int expression = 9;
        if( x == true ) {

            if ( x == true)
                System.out.println("this is not a block");

            if (z  == false){
                System.out.println("this is a block");
            }
        }
    }
}